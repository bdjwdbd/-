# GitHub 推送认证方案

## 问题

推送代码到 GitHub 需要认证，当前环境没有配置凭据。

---

## 方案一：使用 Personal Access Token（推荐）

### 步骤 1：创建 GitHub Token

1. 访问 https://github.com/settings/tokens
2. 点击 "Generate new token (classic)"
3. 勾选 `repo` 权限
4. 点击 "Generate token"
5. **复制 Token**（只显示一次）

### 步骤 2：推送代码

```bash
cd /home/sandbox/.openclaw/workspace/humanoid-agent

# 使用 Token 推送（替换 YOUR_TOKEN）
git push https://YOUR_TOKEN@github.com/bdjwbdb/humanoid-agent.git main
```

---

## 方案二：使用 SSH 密钥

### 步骤 1：生成 SSH 密钥

```bash
ssh-keygen -t ed25519 -C "your_email@example.com"
# 按 Enter 使用默认路径
# 按 Enter 跳过密码（或设置密码）
```

### 步骤 2：添加到 GitHub

```bash
# 显示公钥
cat ~/.ssh/id_ed25519.pub

# 复制公钥内容，然后：
# 1. 访问 https://github.com/settings/keys
# 2. 点击 "New SSH key"
# 3. 粘贴公钥内容
# 4. 点击 "Add SSH key"
```

### 步骤 3：更新远程地址并推送

```bash
cd /home/sandbox/.openclaw/workspace/humanoid-agent

# 更新为 SSH 地址
git remote set-url origin git@github.com:bdjwbdb/humanoid-agent.git

# 推送
git push -u origin main
```

---

## 方案三：使用 GitHub CLI

### 步骤 1：安装 GitHub CLI

```bash
# 如果有 sudo 权限
sudo yum install gh

# 或下载二进制
curl -sSL https://github.com/cli/cli/releases/download/v2.40.0/gh_2.40.0_linux_arm64.tar.gz | tar xz
sudo mv gh_*/bin/gh /usr/local/bin/
```

### 步骤 2：登录

```bash
gh auth login
# 选择 GitHub.com
# 选择 HTTPS
# 粘贴 Token
```

### 步骤 3：推送

```bash
cd /home/sandbox/.openclaw/workspace/humanoid-agent
git push -u origin main
```

---

## 方案四：手动上传（最简单）

如果以上方案都不可行：

### 步骤 1：打包代码

```bash
cd /home/sandbox/.openclaw/workspace/humanoid-agent
tar czf humanoid-agent.tar.gz --exclude=node_modules --exclude=dist .
```

### 步骤 2：下载到本地

在你的本地电脑上下载 `humanoid-agent.tar.gz`

### 步骤 3：在本地推送

```bash
# 解压
tar xzf humanoid-agent.tar.gz -C humanoid-agent
cd humanoid-agent

# 初始化 Git
git init
git add .
git commit -m "元灵系统 v4.3.0"

# 推送到 GitHub
git remote add origin https://github.com/bdjwbdb/humanoid-agent.git
git push -u origin main
```

---

## 当前状态

| 步骤 | 状态 |
|------|------|
| Git 初始化 | ✅ 完成 |
| 代码提交 | ✅ 完成 |
| 分支重命名 | ✅ main |
| 远程仓库添加 | ✅ 完成 |
| 认证配置 | ⏳ 待配置 |
| 推送代码 | ⏳ 待执行 |

---

## 推荐方案

**最简单：方案四（手动上传）**

1. 打包代码
2. 下载到本地
3. 在本地推送到 GitHub

**最快：方案一（Token）**

1. 创建 Token
2. 使用 Token URL 推送

---

*创建时间：2026-04-15*
